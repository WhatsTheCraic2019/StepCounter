package com.marianhello.bgloc;

public interface ConnectivityListener {
    boolean hasConnectivity();
}
