package com.evgenii.jsevaluator.interfaces;

public interface HandlerWrapperInterface {
	public void post(Runnable r);
}
