var BMR = 0;
function computeBMR(event) {
	event.preventDefault();
	var metric = document.getElementById("bmr_input_one");
	var imperial = document.getElementById("bmr_input_two");
	var age = parseInt(document.getElementById("bmr_age_input").value);
	var male = document.getElementById("bmr_gender_male");
	var female = document.getElementById("bmr_gender_female");
	var height = parseInt(document.getElementById("height_input").value);
	var weight = parseInt(document.getElementById("weight_input").value); 
   
   document.getElementById("bmrresponse").style.display = "block";
	
	var met = metric.value;
	var imper = imperial.value;
	var age_years = age.value;
	var male_human = male.value;
	var female_human = female.value;
	var height_body = height.value;
	var weight_body = weight.value;

	if(isNaN(height) || isNaN(weight) || isNaN(age)){
		alert("Please enter your height, weight and age");
		return false;
		}

		
	if(document.getElementById("bmr_gender_male").checked && document.getElementById("bmr_input_one").checked){
					BMR = 66 + 6.2 * document.getElementById("weight_input").value + 12.7 * document.getElementById("height_input").value - 6.76 * document.getElementById("bmr_age_input").value 
					}
					
	if(document.getElementById("bmr_gender_female").checked && document.getElementById("bmr_input_one").checked){
                    BMR = 655.1 + 4.35 * document.getElementById("weight_input").value + 4.7 * document.getElementById("height_input").value - 4.7 * document.getElementById("bmr_age_input").value 
					}

    if(document.getElementById("bmr_gender_male").checked && document.getElementById("bmr_input_two").checked){
	                BMR = 66.5 + 13.75 * document.getElementById("weight_input").value + 5.003 * document.getElementById("height_input").value - 6.755 * document.getElementById("bmr_age_input").value 
					}

    if(document.getElementById("bmr_gender_female").checked && document.getElementById("bmr_input_two").checked){
	                BMR = 655.1 + 9.563 * document.getElementById("weight_input").value + 1.850 * document.getElementById("height_input").value - 4.676 * document.getElementById("bmr_age_input").value
					}					

	//DISPLAY RESULT
	document.getElementById("bmr_output").innerText = BMR.toFixed('1') + " Calories / per day";
}
				
				
		function alterRadio(){
			var metrics = {
				imper: {
					heightunits: "Inches"
				},
				meter: {
					heightunits: "Centimetres"
				}
			}
			
			var imperial = {
				impers: {
					weightunits: "Pounds"
				},
				meters: {
					weightunits: "Kilograms"
				}
			}		
//radio buttons function 
			if (document.getElementById("bmr_input_one").checked) {
				document.getElementById("bmr_height_units").innerText = metrics.imper.heightunits; 
				document.getElementById("bmr_weight_units").innerText = imperial.impers.weightunits; }
				
				
				
			
			if (document.getElementById("bmr_input_two").checked) {
				document.getElementById("bmr_height_units").innerText = metrics.meter.heightunits;
				document.getElementById("bmr_weight_units").innerText = imperial.meters.weightunits;
			     }
				  }	
				 